'use client'

import { useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Camera, Upload, X, Check, AlertCircle, Zap } from 'lucide-react'
import { motion } from 'framer-motion'
import { useAuthStore } from '@/store/auth'

interface MealAnalysis {
  name: string
  description: string
  calories: number
  protein: number
  carbs: number
  fat: number
  fiber: number
  sugar: number
  sodium: number
}

interface DailyStats {
  totalCalories: number
  dailyGoal: number
  remainingCalories: number
  percentage: number
}

export default function MealScanner({ onClose }: { onClose: () => void }) {
  const [image, setImage] = useState<string | null>(null)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [analysis, setAnalysis] = useState<MealAnalysis | null>(null)
  const [dailyStats, setDailyStats] = useState<DailyStats | null>(null)
  const [mealType, setMealType] = useState<string>('lunch')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { user } = useAuthStore()

  const handleImageCapture = (file: File) => {
    const reader = new FileReader()
    reader.onload = (e) => {
      setImage(e.target?.result as string)
      setAnalysis(null)
    }
    reader.readAsDataURL(file)
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      handleImageCapture(file)
    }
  }

  const handleCameraCapture = () => {
    // In a real app, this would open the camera
    // For now, we'll simulate with file input
    fileInputRef.current?.click()
  }

  const analyzeMeal = async () => {
    if (!image || !user) return

    setIsAnalyzing(true)
    
    try {
      const response = await fetch('/api/meals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.id,
          imageUrl: image,
          mealType
        })
      })

      const data = await response.json()

      if (response.ok) {
        setAnalysis({
          name: data.meal.name,
          description: data.meal.description,
          calories: data.meal.calories,
          protein: data.meal.protein || 0,
          carbs: data.meal.carbs || 0,
          fat: data.meal.fat || 0,
          fiber: data.meal.fiber || 0,
          sugar: data.meal.sugar || 0,
          sodium: data.meal.sodium || 0
        })
        setDailyStats(data.dailyStats)
      } else {
        alert('Erro ao analisar refeição')
      }
    } catch (error) {
      alert('Erro ao analisar refeição')
    } finally {
      setIsAnalyzing(false)
    }
  }

  const resetScanner = () => {
    setImage(null)
    setAnalysis(null)
    setDailyStats(null)
  }

  const mealTypes = [
    { value: 'breakfast', label: 'Café da Manhã' },
    { value: 'lunch', label: 'Almoço' },
    { value: 'dinner', label: 'Jantar' },
    { value: 'snack', label: 'Lanche' }
  ]

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-2xl max-h-[90vh] overflow-y-auto"
      >
        <Card className="bg-white/95 backdrop-blur-sm border-0 shadow-2xl">
          <CardContent className="p-6">
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
                  <Camera className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold">Scanner de Refeições</h2>
                  <p className="text-gray-600">Tire uma foto e descubra as calorias</p>
                </div>
              </div>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="w-5 h-5" />
              </Button>
            </div>

            {!image ? (
              /* Image Capture */
              <div className="space-y-6">
                <div className="border-2 border-dashed border-purple-300 rounded-xl p-8 text-center bg-purple-50/50">
                  <Camera className="w-16 h-16 text-purple-600 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Capture sua refeição</h3>
                  <p className="text-gray-600 mb-4">Tire uma foto ou envie uma imagem da sua refeição</p>
                  
                  <div className="flex gap-4 justify-center">
                    <Button 
                      onClick={handleCameraCapture}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    >
                      <Camera className="w-4 h-4 mr-2" />
                      Tirar Foto
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => fileInputRef.current?.click()}
                      className="border-purple-600 text-purple-600 hover:bg-purple-50"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Enviar Imagem
                    </Button>
                  </div>
                  
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleFileInput}
                    className="hidden"
                  />
                </div>

                {/* Meal Type Selection */}
                <div>
                  <label className="block text-sm font-medium mb-2">Tipo de Refeição</label>
                  <div className="grid grid-cols-2 gap-2">
                    {mealTypes.map((type) => (
                      <Button
                        key={type.value}
                        variant={mealType === type.value ? "default" : "outline"}
                        onClick={() => setMealType(type.value)}
                        className={mealType === type.value ? "bg-purple-600 hover:bg-purple-700" : "border-purple-600 text-purple-600 hover:bg-purple-50"}
                      >
                        {type.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </div>
            ) : !analysis ? (
              /* Image Preview */
              <div className="space-y-6">
                <div className="relative">
                  <img
                    src={image}
                    alt="Refeição"
                    className="w-full h-64 object-cover rounded-xl"
                  />
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={resetScanner}
                    className="absolute top-2 right-2 bg-black/50 text-white hover:bg-black/70"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                <div className="text-center">
                  <p className="text-gray-600 mb-4">Imagem capturada! Analisar com IA?</p>
                  <Button
                    onClick={analyzeMeal}
                    disabled={isAnalyzing}
                    className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    size="lg"
                  >
                    {isAnalyzing ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                        Analisando...
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Analisar Refeição
                      </>
                    )}
                  </Button>
                </div>
              </div>
            ) : (
              /* Analysis Results */
              <div className="space-y-6">
                <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Check className="w-5 h-5 text-green-600" />
                    <h3 className="font-semibold text-green-800">Análise Concluída!</h3>
                  </div>
                  <p className="text-green-700">{analysis.description}</p>
                </div>

                <Card className="bg-gradient-to-br from-purple-50 to-blue-50 border-0">
                  <CardContent className="p-6">
                    <h4 className="font-semibold mb-4">Informações Nutricionais</h4>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div className="text-center p-3 bg-white rounded-lg">
                        <div className="text-2xl font-bold text-purple-600">{analysis.calories}</div>
                        <div className="text-sm text-gray-600">Calorias</div>
                      </div>
                      <div className="text-center p-3 bg-white rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{analysis.protein}g</div>
                        <div className="text-sm text-gray-600">Proteínas</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-sm">
                      <div className="text-center p-2 bg-white rounded">
                        <div className="font-semibold">{analysis.carbs}g</div>
                        <div className="text-gray-600">Carboidratos</div>
                      </div>
                      <div className="text-center p-2 bg-white rounded">
                        <div className="font-semibold">{analysis.fat}g</div>
                        <div className="text-gray-600">Gorduras</div>
                      </div>
                      <div className="text-center p-2 bg-white rounded">
                        <div className="font-semibold">{analysis.fiber}g</div>
                        <div className="text-gray-600">Fibras</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {dailyStats && (
                  <Card className="bg-white border-0">
                    <CardContent className="p-6">
                      <h4 className="font-semibold mb-4">Seu Progresso Hoje</h4>
                      
                      <div className="mb-4">
                        <div className="flex justify-between mb-2">
                          <span className="text-sm text-gray-600">Calorias consumidas</span>
                          <span className="text-sm font-semibold">
                            {dailyStats.totalCalories} / {dailyStats.dailyGoal}
                          </span>
                        </div>
                        <Progress 
                          value={Math.min(dailyStats.percentage, 100)} 
                          className="h-3"
                        />
                      </div>

                      <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                        <span className="text-sm font-medium">Calorias restantes</span>
                        <Badge className={dailyStats.remainingCalories > 0 ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}>
                          {dailyStats.remainingCalories > 0 ? '+' : ''}{dailyStats.remainingCalories}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                )}

                <div className="flex gap-4">
                  <Button
                    onClick={resetScanner}
                    variant="outline"
                    className="flex-1 border-purple-600 text-purple-600 hover:bg-purple-50"
                  >
                    Escanear Outra
                  </Button>
                  <Button
                    onClick={onClose}
                    className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  >
                    Concluir
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
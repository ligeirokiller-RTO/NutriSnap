'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Badge } from '@/components/ui/badge'
import { Camera, ArrowRight, ArrowLeft, Sparkles, Target, Users } from 'lucide-react'
import { motion } from 'framer-motion'
import { useAuthStore } from '@/store/auth'

interface OnboardingData {
  name: string
  email: string
  password: string
  age: string
  height: string
  weight: string
  gender: string
  goal: string
  activityLevel: string
}

export default function OnboardingFlow() {
  const [step, setStep] = useState(0)
  const [data, setData] = useState<OnboardingData>({
    name: '',
    email: '',
    password: '',
    age: '',
    height: '',
    weight: '',
    gender: '',
    goal: '',
    activityLevel: ''
  })
  
  const { register, isLoading } = useAuthStore()

  const steps = [
    {
      title: "Bem-vindo ao NutriSnap!",
      subtitle: "Transforme sua alimentação em um jogo divertido",
      content: <WelcomeStep />
    },
    {
      title: "Dados Pessoais",
      subtitle: "Vamos nos conhecer melhor",
      content: <PersonalDataStep data={data} setData={setData} />
    },
    {
      title: "Seu Objetivo",
      subtitle: "O que você quer alcançar?",
      content: <GoalStep data={data} setData={setData} />
    },
    {
      title: "Nível de Atividade",
      subtitle: "Como é seu dia a dia?",
      content: <ActivityStep data={data} setData={setData} />
    },
    {
      title: "Quase lá!",
      subtitle: "Crie sua conta",
      content: <AccountStep data={data} setData={setData} />
    }
  ]

  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1)
    } else {
      handleSubmit()
    }
  }

  const handlePrevious = () => {
    if (step > 0) {
      setStep(step - 1)
    }
  }

  const handleSubmit = async () => {
    const success = await register({
      ...data,
      age: parseInt(data.age),
      height: parseFloat(data.height),
      weight: parseFloat(data.weight)
    })

    if (!success) {
      alert('Erro ao criar conta. Tente novamente.')
    }
  }

  const isStepValid = () => {
    switch (step) {
      case 1:
        return data.name && data.age && data.height && data.weight && data.gender
      case 2:
        return data.goal
      case 3:
        return data.activityLevel
      case 4:
        return data.email && data.password
      default:
        return true
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-md"
      >
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <Badge variant="outline" className="text-purple-600 border-purple-600">
              Passo {step + 1} de {steps.length}
            </Badge>
            <div className="flex gap-1">
              {steps.map((_, index) => (
                <div
                  key={index}
                  className={`h-2 w-8 rounded-full transition-colors ${
                    index <= step ? 'bg-gradient-to-r from-purple-600 to-blue-600' : 'bg-gray-200'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Main Card */}
        <Card className="bg-white/90 backdrop-blur-sm border-0 shadow-xl">
          <CardContent className="p-8">
            {/* Header */}
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Camera className="w-8 h-8 text-white" />
              </div>
              <h2 className="text-2xl font-bold mb-2">{steps[step].title}</h2>
              <p className="text-gray-600">{steps[step].subtitle}</p>
            </div>

            {/* Content */}
            <div className="mb-8">
              {steps[step].content}
            </div>

            {/* Navigation */}
            <div className="flex gap-4">
              {step > 0 && (
                <Button
                  variant="outline"
                  onClick={handlePrevious}
                  className="flex-1"
                  disabled={isLoading}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Anterior
                </Button>
              )}
              <Button
                onClick={handleNext}
                className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                disabled={!isStepValid() || isLoading}
              >
                {isLoading ? (
                  'Processando...'
                ) : step === steps.length - 1 ? (
                  'Criar Conta'
                ) : (
                  <>
                    Próximo
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Features Preview */}
        {step === 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="mt-8 grid grid-cols-3 gap-4"
          >
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                <Camera className="w-6 h-6 text-purple-600" />
              </div>
              <p className="text-xs text-gray-600">Scanner IA</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                <Target className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-xs text-gray-600">Desafios</p>
            </div>
            <div className="text-center">
              <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-pink-600" />
              </div>
              <p className="text-xs text-gray-600">Comunidade</p>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}

function WelcomeStep() {
  return (
    <div className="text-center space-y-4">
      <Sparkles className="w-16 h-16 text-purple-600 mx-auto mb-4" />
      <p className="text-gray-700">
        Com o NutriSnap, você vai tirar fotos das suas refeições e descobrir instantaneamente as calorias, 
        participar de desafios personalizados e conectar-se com uma comunidade fitness motivada.
      </p>
      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-4">
        <p className="text-sm font-semibold text-purple-800">
          Calcule hoje. Conquiste amanhã.
        </p>
      </div>
    </div>
  )
}

function PersonalDataStep({ data, setData }: { data: OnboardingData, setData: Function }) {
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Nome completo</Label>
        <Input
          id="name"
          value={data.name}
          onChange={(e) => setData({ ...data, name: e.target.value })}
          placeholder="Seu nome"
          className="mt-1"
        />
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="age">Idade</Label>
          <Input
            id="age"
            type="number"
            value={data.age}
            onChange={(e) => setData({ ...data, age: e.target.value })}
            placeholder="25"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="gender">Gênero</Label>
          <Select value={data.gender} onValueChange={(value) => setData({ ...data, gender: value })}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder="Selecione" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="male">Masculino</SelectItem>
              <SelectItem value="female">Feminino</SelectItem>
              <SelectItem value="other">Outro</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="height">Altura (cm)</Label>
          <Input
            id="height"
            type="number"
            value={data.height}
            onChange={(e) => setData({ ...data, height: e.target.value })}
            placeholder="170"
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="weight">Peso (kg)</Label>
          <Input
            id="weight"
            type="number"
            value={data.weight}
            onChange={(e) => setData({ ...data, weight: e.target.value })}
            placeholder="70"
            className="mt-1"
          />
        </div>
      </div>
    </div>
  )
}

function GoalStep({ data, setData }: { data: OnboardingData, setData: Function }) {
  const goals = [
    { value: 'lose_weight', label: 'Perder Peso', description: 'Reduzir o peso corporal de forma saudável' },
    { value: 'gain_muscle', label: 'Ganhar Massa', description: 'Aumentar massa muscular' },
    { value: 'eat_healthy', label: 'Comer Saudável', description: 'Melhorar hábitos alimentares' },
    { value: 'maintenance', label: 'Manutenção', description: 'Manter o peso atual' },
    { value: 'body_recomposition', label: 'Recomposição', description: 'Perder gordura e ganhar massa' }
  ]

  return (
    <RadioGroup value={data.goal} onValueChange={(value) => setData({ ...data, goal: value })}>
      <div className="space-y-3">
        {goals.map((goal) => (
          <div key={goal.value} className="flex items-center space-x-2">
            <RadioGroupItem value={goal.value} id={goal.value} />
            <Label htmlFor={goal.value} className="flex-1 cursor-pointer">
              <div className="font-medium">{goal.label}</div>
              <div className="text-sm text-gray-600">{goal.description}</div>
            </Label>
          </div>
        ))}
      </div>
    </RadioGroup>
  )
}

function ActivityStep({ data, setData }: { data: OnboardingData, setData: Function }) {
  const activities = [
    { value: 'sedentary', label: 'Sedentário', description: 'Pouco ou nenhum exercício' },
    { value: 'light', label: 'Leve', description: 'Exercício leve 1-3 dias/semana' },
    { value: 'moderate', label: 'Moderado', description: 'Exercício moderado 3-5 dias/semana' },
    { value: 'active', label: 'Ativo', description: 'Exercício intenso 6-7 dias/semana' },
    { value: 'very_active', label: 'Muito Ativo', description: 'Exercício muito intenso ou trabalho físico' }
  ]

  return (
    <RadioGroup value={data.activityLevel} onValueChange={(value) => setData({ ...data, activityLevel: value })}>
      <div className="space-y-3">
        {activities.map((activity) => (
          <div key={activity.value} className="flex items-center space-x-2">
            <RadioGroupItem value={activity.value} id={activity.value} />
            <Label htmlFor={activity.value} className="flex-1 cursor-pointer">
              <div className="font-medium">{activity.label}</div>
              <div className="text-sm text-gray-600">{activity.description}</div>
            </Label>
          </div>
        ))}
      </div>
    </RadioGroup>
  )
}

function AccountStep({ data, setData }: { data: OnboardingData, setData: Function }) {
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="email">E-mail</Label>
        <Input
          id="email"
          type="email"
          value={data.email}
          onChange={(e) => setData({ ...data, email: e.target.value })}
          placeholder="seu@email.com"
          className="mt-1"
        />
      </div>
      
      <div>
        <Label htmlFor="password">Senha</Label>
        <Input
          id="password"
          type="password"
          value={data.password}
          onChange={(e) => setData({ ...data, password: e.target.value })}
          placeholder="Crie uma senha forte"
          className="mt-1"
        />
      </div>

      <div className="bg-gradient-to-r from-purple-50 to-blue-50 rounded-xl p-4">
        <p className="text-sm text-purple-800">
          <strong>Meta calórica diária estimada:</strong> Com base nos seus dados, 
          sua meta será calculada automaticamente após o cadastro.
        </p>
      </div>
    </div>
  )
}
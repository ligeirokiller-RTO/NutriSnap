import { create } from 'zustand'

interface User {
  id: string
  name: string
  email: string
  age: number
  height: number
  weight: number
  gender: string
  goal: string
  activityLevel: string
  dailyCalorieGoal: number
  isPremium: boolean
  avatar?: string
  bio?: string
}

interface AuthState {
  user: User | null
  isLoading: boolean
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: any) => Promise<boolean>
  logout: () => void
  updateUser: (userData: Partial<User>) => void
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  isLoading: false,

  login: async (email: string, password: string) => {
    set({ isLoading: true })
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      })

      const data = await response.json()

      if (response.ok) {
        set({ user: data.user, isLoading: false })
        localStorage.setItem('nutrisnap_user', JSON.stringify(data.user))
        return true
      } else {
        set({ isLoading: false })
        return false
      }
    } catch (error) {
      set({ isLoading: false })
      return false
    }
  },

  register: async (userData: any) => {
    set({ isLoading: true })
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(userData)
      })

      const data = await response.json()

      if (response.ok) {
        set({ user: data.user, isLoading: false })
        localStorage.setItem('nutrisnap_user', JSON.stringify(data.user))
        return true
      } else {
        set({ isLoading: false })
        return false
      }
    } catch (error) {
      set({ isLoading: false })
      return false
    }
  },

  logout: () => {
    set({ user: null })
    localStorage.removeItem('nutrisnap_user')
  },

  updateUser: (userData: Partial<User>) => {
    const currentUser = get().user
    if (currentUser) {
      const updatedUser = { ...currentUser, ...userData }
      set({ user: updatedUser })
      localStorage.setItem('nutrisnap_user', JSON.stringify(updatedUser))
    }
  }
}))

// Initialize user from localStorage
if (typeof window !== 'undefined') {
  const savedUser = localStorage.getItem('nutrisnap_user')
  if (savedUser) {
    useAuthStore.setState({ user: JSON.parse(savedUser) })
  }
}
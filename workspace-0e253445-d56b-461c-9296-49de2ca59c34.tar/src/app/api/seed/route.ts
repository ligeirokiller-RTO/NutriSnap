import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    // Create default challenges
    const challenges = [
      {
        title: "Déficit Calórico de 5 Dias",
        description: "Mantenha um déficit calórico por 5 dias consecutivos",
        type: "calorie_deficit",
        targetValue: 500,
        unit: "calorias",
        duration: 7,
        points: 100,
        isActive: true
      },
      {
        title: "Redução de Açúcar",
        description: "Consuma 20% menos açúcar esta semana",
        type: "sugar_reduction",
        targetValue: 20,
        unit: "percent",
        duration: 7,
        points: 75,
        isActive: true
      },
      {
        title: "Hidratação Perfeita",
        description: "Beba 2L de água por dia durante 5 dias",
        type: "water_intake",
        targetValue: 2000,
        unit: "ml",
        duration: 5,
        points: 50,
        isActive: true
      },
      {
        title: "Proteína em Dia",
        description: "Consuma pelo menos 1g de proteína por kg de peso corporal",
        type: "protein_target",
        targetValue: 100,
        unit: "gramas",
        duration: 3,
        points: 60,
        isActive: true
      },
      {
        title: "Refeições Registradas",
        description: "Registre todas as refeições por 7 dias",
        type: "meal_tracking",
        targetValue: 21,
        unit: "refeições",
        duration: 7,
        points: 80,
        isActive: true
      }
    ]

    for (const challenge of challenges) {
      // Check if challenge already exists
      const existing = await db.challenge.findFirst({
        where: { title: challenge.title }
      })
      
      if (!existing) {
        await db.challenge.create({
          data: challenge
        })
      }
    }

    // Create default achievements
    const achievements = [
      {
        title: "Primeiro Passo",
        description: "Registrar sua primeira refeição",
        icon: "🍽️",
        points: 10,
        condition: "first_meal"
      },
      {
        title: "Semana Completa",
        description: "Registrar refeições por 7 dias seguidos",
        icon: "📅",
        points: 50,
        condition: "week_streak"
      },
      {
        title: "Mestre das Calorias",
        description: "Manter meta calórica por 30 dias",
        icon: "🎯",
        points: 200,
        condition: "calorie_master"
      },
      {
        title: "Desafista",
        description: "Completar 10 desafios",
        icon: "🏆",
        points: 150,
        condition: "challenge_warrior"
      },
      {
        title: "Social Fitness",
        description: "Fazer 50 posts na comunidade",
        icon: "👥",
        points: 100,
        condition: "social_butterfly"
      },
      {
        title: "Perda de Peso",
        description: "Perder 5kg de forma saudável",
        icon: "⚖️",
        points: 300,
        condition: "weight_loss_5kg"
      },
      {
        title: "Ganho de Massa",
        description: "Ganhar 3kg de massa muscular",
        icon: "💪",
        points: 300,
        condition: "muscle_gain_3kg"
      },
      {
        title: "Hidratação",
        description: "Bebber 2L de água por 30 dias",
        icon: "💧",
        points: 80,
        condition: "hydration_master"
      }
    ]

    for (const achievement of achievements) {
      // Check if achievement already exists
      const existing = await db.achievement.findFirst({
        where: { title: achievement.title }
      })
      
      if (!existing) {
        await db.achievement.create({
          data: achievement
        })
      }
    }

    return NextResponse.json({
      message: "Dados iniciais criados com sucesso",
      challenges: challenges.length,
      achievements: achievements.length
    })

  } catch (error) {
    console.error('Seed error:', error)
    return NextResponse.json(
      { error: 'Erro ao criar dados iniciais: ' + error.message },
      { status: 500 }
    )
  }
}
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const limit = parseInt(searchParams.get('limit') || '10')
    const offset = parseInt(searchParams.get('offset') || '0')

    let whereClause: any = {}

    if (userId) {
      // Get posts from users that this user follows
      const following = await db.follow.findMany({
        where: { followerId: userId },
        select: { followingId: true }
      })

      const followingIds = following.map(f => f.followingId)
      followingIds.push(userId) // Include user's own posts

      whereClause.userId = { in: followingIds }
    }

    const posts = await db.post.findMany({
      where: whereClause,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        },
        likes: {
          select: {
            userId: true
          }
        },
        comments: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                avatar: true
              }
            }
          },
          orderBy: { createdAt: 'desc' },
          take: 3
        }
      },
      orderBy: { createdAt: 'desc' },
      take: limit,
      skip: offset
    })

    // Format posts with like status
    const formattedPosts = posts.map(post => ({
      ...post,
      isLiked: userId ? post.likes.some(like => like.userId === userId) : false,
      likeCount: post.likes.length,
      commentCount: post.comments.length
    }))

    return NextResponse.json({ posts: formattedPosts })

  } catch (error) {
    console.error('Get posts error:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar posts' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId, content, imageUrl, type } = await request.json()

    if (!userId) {
      return NextResponse.json(
        { error: 'ID do usuário é obrigatório' },
        { status: 400 }
      )
    }

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'Usuário não encontrado' },
        { status: 404 }
      )
    }

    // Create post
    const post = await db.post.create({
      data: {
        userId,
        content: content || null,
        imageUrl: imageUrl || null,
        type: type || 'general'
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            avatar: true
          }
        }
      }
    })

    return NextResponse.json({
      message: 'Post criado com sucesso',
      post: {
        ...post,
        isLiked: false,
        likeCount: 0,
        commentCount: 0
      }
    })

  } catch (error) {
    console.error('Create post error:', error)
    return NextResponse.json(
      { error: 'Erro ao criar post' },
      { status: 500 }
    )
  }
}
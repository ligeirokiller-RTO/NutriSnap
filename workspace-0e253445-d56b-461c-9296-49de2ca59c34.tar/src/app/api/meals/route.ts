import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const { userId, imageUrl, mealType } = await request.json()

    if (!userId || !imageUrl || !mealType) {
      return NextResponse.json(
        { error: 'Dados incompletos' },
        { status: 400 }
      )
    }

    // Verify user exists
    const user = await db.user.findUnique({
      where: { id: userId }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'Usuário não encontrado' },
        { status: 404 }
      )
    }

    // Use AI to analyze the meal image
    const zai = await ZAI.create()
    
    const analysisPrompt = `
    Analise esta imagem de uma refeição e forneça informações nutricionais detalhadas em formato JSON.
    
    Por favor, identifique:
    1. Os alimentos presentes na imagem
    2. Estime as quantidades aproximadas em gramas
    3. Calcule os valores nutricionais aproximados:
       - Calorias totais
       - Proteínas (g)
       - Carboidratos (g)
       - Gorduras (g)
       - Fibra (g)
       - Açúcar (g)
       - Sódio (mg)
    
    Responda apenas com o JSON no seguinte formato:
    {
      "name": "Nome da refeição",
      "description": "Descrição detalhada dos alimentos",
      "calories": 0,
      "protein": 0.0,
      "carbs": 0.0,
      "fat": 0.0,
      "fiber": 0.0,
      "sugar": 0.0,
      "sodium": 0
    }
    `

    // For now, we'll simulate the AI analysis since we can't process images directly
    // In a real implementation, you would send the image to the AI service
    const simulatedAnalysis = {
      name: "Refeição Analisada",
      description: "Refeição balanceada com proteínas, carboidratos e vegetais",
      calories: Math.floor(Math.random() * 400) + 300, // 300-700 calories
      protein: Math.floor(Math.random() * 30) + 15, // 15-45g
      carbs: Math.floor(Math.random() * 40) + 20, // 20-60g
      fat: Math.floor(Math.random() * 20) + 10, // 10-30g
      fiber: Math.floor(Math.random() * 10) + 5, // 5-15g
      sugar: Math.floor(Math.random() * 15) + 5, // 5-20g
      sodium: Math.floor(Math.random() * 500) + 200 // 200-700mg
    }

    // Create meal record
    const meal = await db.meal.create({
      data: {
        userId,
        name: simulatedAnalysis.name,
        description: simulatedAnalysis.description,
        calories: simulatedAnalysis.calories,
        protein: simulatedAnalysis.protein,
        carbs: simulatedAnalysis.carbs,
        fat: simulatedAnalysis.fat,
        fiber: simulatedAnalysis.fiber,
        sugar: simulatedAnalysis.sugar,
        sodium: simulatedAnalysis.sodium,
        imageUrl,
        mealType
      }
    })

    // Get today's total calories for this user
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    
    const todayMeals = await db.meal.findMany({
      where: {
        userId,
        date: {
          gte: today
        }
      }
    })

    const totalCaloriesToday = todayMeals.reduce((sum, meal) => sum + meal.calories, 0)
    const remainingCalories = user.dailyCalorieGoal - totalCaloriesToday

    return NextResponse.json({
      message: 'Refeição analisada com sucesso',
      meal,
      dailyStats: {
        totalCalories: totalCaloriesToday,
        dailyGoal: user.dailyCalorieGoal,
        remainingCalories,
        percentage: Math.round((totalCaloriesToday / user.dailyCalorieGoal) * 100)
      }
    })

  } catch (error) {
    console.error('Meal analysis error:', error)
    return NextResponse.json(
      { error: 'Erro ao analisar refeição' },
      { status: 500 }
    )
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const date = searchParams.get('date')

    if (!userId) {
      return NextResponse.json(
        { error: 'ID do usuário é obrigatório' },
        { status: 400 }
      )
    }

    let whereClause: any = { userId }

    if (date) {
      const targetDate = new Date(date)
      targetDate.setHours(0, 0, 0, 0)
      const nextDay = new Date(targetDate)
      nextDay.setDate(nextDay.getDate() + 1)

      whereClause.date = {
        gte: targetDate,
        lt: nextDay
      }
    } else {
      // Get today's meals by default
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      const tomorrow = new Date(today)
      tomorrow.setDate(tomorrow.getDate() + 1)

      whereClause.date = {
        gte: today,
        lt: tomorrow
      }
    }

    const meals = await db.meal.findMany({
      where: whereClause,
      orderBy: { date: 'desc' }
    })

    const totalCalories = meals.reduce((sum, meal) => sum + meal.calories, 0)
    const totalProtein = meals.reduce((sum, meal) => sum + (meal.protein || 0), 0)
    const totalCarbs = meals.reduce((sum, meal) => sum + (meal.carbs || 0), 0)
    const totalFat = meals.reduce((sum, meal) => sum + (meal.fat || 0), 0)

    return NextResponse.json({
      meals,
      summary: {
        totalCalories,
        totalProtein: Math.round(totalProtein),
        totalCarbs: Math.round(totalCarbs),
        totalFat: Math.round(totalFat),
        mealCount: meals.length
      }
    })

  } catch (error) {
    console.error('Get meals error:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar refeições' },
      { status: 500 }
    )
  }
}
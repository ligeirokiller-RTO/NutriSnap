import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const active = searchParams.get('active')

    if (active === 'true') {
      // Get active challenges
      const challenges = await db.challenge.findMany({
        where: { isActive: true },
        orderBy: { createdAt: 'desc' }
      })

      return NextResponse.json({ challenges })
    }

    if (userId) {
      // Get user's challenges
      const userChallenges = await db.userChallenge.findMany({
        where: { userId },
        include: {
          challenge: true
        },
        orderBy: { startDate: 'desc' }
      })

      return NextResponse.json({ userChallenges })
    }

    // Get all challenges
    const challenges = await db.challenge.findMany({
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ challenges })

  } catch (error) {
    console.error('Get challenges error:', error)
    return NextResponse.json(
      { error: 'Erro ao buscar desafios' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userId, challengeId } = await request.json()

    if (!userId || !challengeId) {
      return NextResponse.json(
        { error: 'Dados incompletos' },
        { status: 400 }
      )
    }

    // Check if user already has this challenge
    const existingUserChallenge = await db.userChallenge.findUnique({
      where: {
        userId_challengeId: {
          userId,
          challengeId
        }
      }
    })

    if (existingUserChallenge) {
      return NextResponse.json(
        { error: 'Usuário já participa deste desafio' },
        { status: 400 }
      )
    }

    // Get challenge details
    const challenge = await db.challenge.findUnique({
      where: { id: challengeId }
    })

    if (!challenge) {
      return NextResponse.json(
        { error: 'Desafio não encontrado' },
        { status: 404 }
      )
    }

    // Create user challenge
    const userChallenge = await db.userChallenge.create({
      data: {
        userId,
        challengeId,
        status: 'in_progress',
        startDate: new Date(),
        endDate: new Date(Date.now() + challenge.duration * 24 * 60 * 60 * 1000) // Add duration days
      },
      include: {
        challenge: true
      }
    })

    return NextResponse.json({
      message: 'Desafio aceito com sucesso',
      userChallenge
    })

  } catch (error) {
    console.error('Accept challenge error:', error)
    return NextResponse.json(
      { error: 'Erro ao aceitar desafio' },
      { status: 500 }
    )
  }
}
import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'

export async function POST(request: NextRequest) {
  try {
    const { name, email, password, age, height, weight, gender, goal, activityLevel } = await request.json()

    // Validate required fields
    if (!name || !email || !password || !age || !height || !weight || !gender || !goal || !activityLevel) {
      return NextResponse.json(
        { error: 'Todos os campos são obrigatórios' },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'Usuário já existe com este email' },
        { status: 400 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Calculate daily calorie goal based on user data
    let bmr: number
    if (gender === 'male') {
      bmr = 88.362 + (13.397 * weight) + (4.799 * height) - (5.677 * age)
    } else {
      bmr = 447.593 + (9.247 * weight) + (3.098 * height) - (4.330 * age)
    }

    // Activity multipliers
    const activityMultipliers = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9
    }

    const tdee = bmr * (activityMultipliers[activityLevel as keyof typeof activityMultipliers] || 1.55)

    // Adjust based on goal
    let dailyCalorieGoal = tdee
    if (goal === 'lose_weight') {
      dailyCalorieGoal = tdee * 0.8 // 20% deficit
    } else if (goal === 'gain_muscle') {
      dailyCalorieGoal = tdee * 1.15 // 15% surplus
    }

    // Create user
    const user = await db.user.create({
      data: {
        name,
        email,
        password: hashedPassword,
        age,
        height,
        weight,
        gender,
        goal,
        activityLevel,
        dailyCalorieGoal: Math.round(dailyCalorieGoal)
      }
    })

    // Remove password from response
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      message: 'Usuário criado com sucesso',
      user: userWithoutPassword
    })

  } catch (error) {
    console.error('Registration error:', error)
    return NextResponse.json(
      { error: 'Erro interno do servidor' },
      { status: 500 }
    )
  }
}
'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Camera, Trophy, Users, Target, Sparkles, Flame, TrendingUp, Heart } from 'lucide-react'
import { motion } from 'framer-motion'
import OnboardingFlow from '@/components/onboarding/OnboardingFlow'
import MealScanner from '@/components/scanner/MealScanner'
import { useAuthStore } from '@/store/auth'

export default function NutriSnapHome() {
  const [mounted, setMounted] = useState(false)
  const [showScanner, setShowScanner] = useState(false)
  const { user } = useAuthStore()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  // If user is not logged in, show onboarding
  if (!user) {
    return <OnboardingFlow />
  }

  // If user is logged in, show dashboard
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50">
      {/* Header */}
      <header className="bg-white/80 backdrop-blur-md border-b border-purple-100 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl flex items-center justify-center">
                <Camera className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                NutriSnap
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <Badge className="bg-gradient-to-r from-purple-600 to-blue-600 text-white">
                {user.isPremium ? 'Premium' : 'Gratuito'}
              </Badge>
              <div className="w-8 h-8 bg-purple-200 rounded-full flex items-center justify-center">
                <span className="text-purple-800 font-semibold text-sm">
                  {user.name.charAt(0).toUpperCase()}
                </span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Welcome Section */}
      <section className="container mx-auto px-4 py-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8"
        >
          <h2 className="text-3xl font-bold mb-2">
            Olá, {user.name}! 👋
          </h2>
          <p className="text-gray-600">
            Sua meta diária: <span className="font-semibold text-purple-600">{user.dailyCalorieGoal} calorias</span>
          </p>
        </motion.div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            onClick={() => setShowScanner(true)}
          >
            <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm cursor-pointer">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-purple-600 to-purple-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Camera className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Scanner</h3>
                <p className="text-gray-600 text-sm">Tirar foto da refeição</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm cursor-pointer">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Desafios</h3>
                <p className="text-gray-600 text-sm">Ver desafios ativos</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
          >
            <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm cursor-pointer">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-pink-600 to-pink-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Comunidade</h3>
                <p className="text-gray-600 text-sm">Ver feed social</p>
              </CardContent>
            </Card>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            <Card className="h-full hover:shadow-lg transition-shadow duration-300 border-0 bg-white/80 backdrop-blur-sm cursor-pointer">
              <CardContent className="p-6 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-green-600 to-green-700 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Trophy className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Conquistas</h3>
                <p className="text-gray-600 text-sm">Ver medalhas</p>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Today's Progress */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="grid md:grid-cols-2 gap-6"
        >
          <Card className="bg-white/80 backdrop-blur-sm border-0">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-4">Progresso de Hoje</h3>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span className="text-sm text-gray-600">Calorias consumidas</span>
                    <span className="text-sm font-semibold">0 / {user.dailyCalorieGoal}</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div className="bg-gradient-to-r from-purple-600 to-blue-600 h-3 rounded-full" style={{ width: '0%' }}></div>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold text-purple-600">0</div>
                    <div className="text-xs text-gray-600">Refeições</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-blue-600">0g</div>
                    <div className="text-xs text-gray-600">Proteínas</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold text-pink-600">0ml</div>
                    <div className="text-xs text-gray-600">Água</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/80 backdrop-blur-sm border-0">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-4">Desafios Ativos</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                  <div>
                    <div className="font-medium text-sm">Nenhum desafio ativo</div>
                    <div className="text-xs text-gray-600">Comece um desafio hoje!</div>
                  </div>
                  <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                    Ver Todos
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {!user.isPremium && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
            className="mt-8"
          >
            <Card className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0">
              <CardContent className="p-6 text-center">
                <Trophy className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Desbloqueie o Premium</h3>
                <p className="mb-4">Libere todos os recursos: desafios ilimitados, rede social completa e muito mais!</p>
                <Button size="lg" className="bg-white text-purple-600 hover:bg-gray-100">
                  Ativar Premium por R$ 49,90
                </Button>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </section>

      {/* Scanner Modal */}
      {showScanner && (
        <MealScanner onClose={() => setShowScanner(false)} />
      )}
    </div>
  )
}